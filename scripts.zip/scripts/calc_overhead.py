import os

total_packets = 0
directory = 'path/to/directory/'

for filename in os.listdir(directory):
    with open(os.path.join(directory, filename), 'r') as file:
        for line in file:
            numbers = line.split()
            if len(numbers) > 1:
                total_packets += abs(int(numbers[1]))

print(total_packets)

total_time = 0

for filename in os.listdir(directory):
    with open(os.path.join(directory, filename), 'r') as file:
        for line in file:
            numbers = line.split()
            if len(numbers) > 0:
                last_number = float(numbers[0])
        total_time += last_number

print(total_time)