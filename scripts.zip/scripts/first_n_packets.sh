#!/bin/bash

input_dir="path/to/input/dir"
output_dir="path/to/output/dir"

for input_file in "$input_dir"/*
do
    output_file="$output_dir"/$(basename "$input_file")
    touch "$output_file"
    head -n 10 "$input_file" > "$output_file"
done