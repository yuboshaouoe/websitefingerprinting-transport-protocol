import dpkt
import socket
import time
import os

def parse_pcap(file_name):
    with open(file_name, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)
        first_timestamp = None
        for timestamp, buf in pcap:
            if first_timestamp is None:
                first_timestamp = timestamp
            timestamp -= first_timestamp
            eth = dpkt.ethernet.Ethernet(buf)
            ip = eth.data
            if isinstance(ip.data, dpkt.tcp.TCP):
                tcp = ip.data
                if isinstance(ip, dpkt.ip.IP):
                    size = ip.len
                elif isinstance(ip, dpkt.ip6.IP6):
                    size = ip.plen
                else:
                    continue
                if tcp.sport < tcp.dport:
                    size = -size
                yield timestamp, size

def write_to_file(file_name, data):
    with open(file_name, 'w') as f:
        for timestamp, size in data:
            f.write(f"{timestamp}\t{size}\n")

def convert_file(file_name, output_directory):
    base_name = os.path.basename(file_name).replace('.pcap', '')
    page_load, port = base_name.split('_localhost:')
    new_file_name = f"{output_directory}/{int(port) - 8080}-{page_load}"
    data = parse_pcap(file_name)
    write_to_file(new_file_name, data)

def convert_directory(input_directory, output_directory):
    for file_name in os.listdir(input_directory):
        if file_name.endswith('.pcap'):
            full_path = os.path.join(input_directory, file_name)
            convert_file(full_path, output_directory)

convert_directory('/home/uboat/Dissertation/back_ups/results/http2_traffic', '/home/uboat/Dissertation/converted_dataset/http2')