#!/bin/bash

input_directory="/home/uboat/Dissertation/crawler-mini-main/results"
output_directory="/home/uboat/Dissertation/csvs/http2"

for pcap_file in "$input_directory"/*.pcap
do
  base_name=$(basename "$pcap_file" .pcap)
  tshark -nn -r "$pcap_file" -T fields -E header=y -E separator=, \
    -e frame.time_epoch -e ip.src -e ip.dst -e tcp.srcport -e tcp.dstport \
    -e ip.proto -e ip.len -e ip.hdr_len -e tcp.hdr_len -e data.len \
    -e tcp.flags -e tcp.options.timestamp.tsval -e tcp.options.timestamp.tsecr \
    -e tcp.seq -e tcp.ack -e tcp.window_size_value -e _ws.expert.message \
    > "$output_directory/$base_name.csv"
done