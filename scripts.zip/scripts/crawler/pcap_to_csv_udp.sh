#!/bin/bash

input_directory="/home/uboat/Dissertation/crawler-mini-main/results"
output_directory="/home/uboat/Dissertation/csvs/http3"

for pcap_file in "$input_directory"/*.pcap
do
  base_name=$(basename "$pcap_file" .pcap)
  tshark -nn -r "$pcap_file" -T fields -E header=y -E separator=, \
    -e frame.time_epoch -e ip.src -e ip.dst -e udp.srcport -e udp.dstport \
    -e ip.proto -e ip.len -e ip.hdr_len -e data.len -e _ws.expert.message \
    > "$output_directory/$base_name.csv"
done