#!/bin/bash

VISITS=100

rm -rf results
mkdir -p results

for i in {0..99}; do
	while read url; do
        python3 main.py $i https://$url
		killall -9 dumpcap
		killall -9 python3
    done <./url.list
done
