import sys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
# from selenium.common.exceptions import NoSuchElementException

from time import sleep

from dumputils import *
from common import *
from utils import *

i, url = sys.argv[1:3]
print(f'Visit {i} to {url}')

chromeOptions = Options()

chromeOptions.add_experimental_option(
  "prefs",
  {
    'profile.managed_default_content_settings.javascript':2
  }
)

chromeOptions.add_argument('--headless')
chromeOptions.add_argument('--no-sandbox')
chromeOptions.add_argument("--ignore-certificate-errors")
chromeOptions.add_argument("--allow-insecure-localhost")
chromeOptions.add_argument('--no-proxy-server')
chromeOptions.add_argument('--enable-quic')
#chromeOptions.add_argument('--origin-to-force-quic-on=localhost:8080')
for x in range(8080, 8099):
    chromeOptions.add_argument(f'--origin-to-force-quic-on=localhost:{x}')


# Initialize the driver
# driver = webdriver.Chrome(options=chromeOptions)

# Navigate to a page that requires JavaScript
# driver.get("https://www.whatismybrowser.com/detect/is-javascript-enabled")

# sleep(2)

# Don't forget to quit the driver after you're done
# driver.quit()


with webdriver.Chrome(options=chromeOptions) as driver:
    sleep(2)
    site = url.split('//')[1].split('.')[0]
    fname = f'/home/uboat/Dissertation/crawler-mini-main/results/{i}_{site}.pcap'
    with Sniffer(path=fname, filter=DEFAULT_FILTER) as sniffer:
        driver.get(url)
        sleep(5)
