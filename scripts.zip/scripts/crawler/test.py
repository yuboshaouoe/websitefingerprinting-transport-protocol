from selenium import webdriver
from time import sleep

coption = webdriver.ChromeOptions()
coption.add_experimental_option('excludeSwitches', ['enable-logging'])
with webdriver.Chrome(options=coption) as driver:
    sleep(2)
    driver.get("https://curl.se/docs/http3.html")
    sleep(5)
