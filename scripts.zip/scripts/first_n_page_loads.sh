#!/bin/bash

input_dir="path/to/input/dir"
output_dir="/path/to/output/dir"

for file in "$input_dir"/*
do
    filename=$(basename "$file")
    y=${filename#*-}  # get the part after the '-'
    # y=${y%.*}  # remove the file extension

    if (( y < 90 )); then
        cp "$file" "$output_dir"
    fi
done